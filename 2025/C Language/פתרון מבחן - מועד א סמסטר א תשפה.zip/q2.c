#include <stdio.h>
#include <stdlib.h>

int strComp(char* str1, char* str2){
    while (*str1 && (*str1 == *str2))
    {
        str1++;
        str2++;
    }
    return *str1 - *str2;
}

int substringSearch(const char *text, const char *pattern) {
    int i, j;
    
    for (i = 0; text[i] != '\0'; i++) {
        for (j = 0; pattern[j] != '\0'; j++) {
            if (text[i + j] != pattern[j])
                break;
        }
        if (pattern[j] == '\0') // Match found
            return i;
    }
    return -1; // Not found
}


int main(){
    char* s1 = "ddd";
    char* s2 = "ddd";
    printf("%d\n", strComp(s1, s2));
    char* s3 = "dde";
    printf("%d\n", strComp(s1, s3));    // negative means s1 is lower
    char* s4 = "dcd";
    printf("%d\n", strComp(s1, s4));    // positive means s1 is greater


    char* text = "The fox runs in the field";
    char* goodSubText = "runs in";
    printf("%d\n", substringSearch(text, goodSubText));

    char* badSubText = "runs on";
    printf("%d\n", substringSearch(text, badSubText));

    return 0;
}