#include <stdio.h>


void doSomething(int* arr, int size, int* r1, int* r2) {
    for (int i = 1; i < size; i++) {
        *(arr + i) += *(arr + i - 1);

        if (*(arr + i) < *(arr + i - 1)) {
            *r1 = i;
        }
        if (*(arr + i) - *(arr + i - 1) > *r2)
        {
            *r2 = *(arr + i) - *(arr + i - 1);
        }
    }
}

int main() {
    int numbers[] = {450, -340, 780, 1020, 900, -250, 700, 910, -300, 300};
    int size = sizeof(numbers) / sizeof(numbers[0]);
    int ll = -1;
    int gg = 0;

    doSomething(numbers, size, &ll, &gg);

    printf("ll = %d\n", ll);
    printf("gg = %d\n", gg);

    return 0;
}


/*
    This program pass an array of values (say, prices or income),
    and two pointers of int variables.
    The function updates the original array with its cumulative sum,
    and in the process also find the last-negative-value (last lost)
    and the largest positive gap in values (greatest gain).

    Input: {450, -340, 780, 1020, 900, -250, 700, 910, -300, 300};

    Table:
    i   *(arr+i)    *(arr+i-1)  *(arr+i) after  r1  r2
    1   -340        450         110             1   0
    2   780         110         890             1   780
    3   1020        890         1910            1   1020
    4   900         1910        2810            1   1020
    5   -250        2810        2560            5   1020
    6   700         2560        3260            5   1020
    7   910         3260        4170            5   1020
    8   -300        4170        3870            8   1020
    9   300         3870        4170            8   1020

    Output:
    "ll = 8"
    "gg = 1020"
*/