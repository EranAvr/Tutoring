#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// a)
struct Student
{
    char name[20];
    int* grades;
    float avg;
};

// b)
struct Student* createStudent(char studName[20]){
    // create pointer-
    struct Student* newStud;
    // request memory in heap-
    newStud = (struct Student*) malloc(sizeof(struct Student));
    // copy name into new student-
    strcpy(newStud->name, studName);
    // return pointer-
    return newStud;
}

// c)
// שימו לב! השאלה המקורית הכילה תקלה
// ולא הוגדר שהפונ' צריכה לקבל מצביע מטיפוס מבנה-תלמיד
// לכן שאלה זו תחושב כבונוס בלבד
void addGrades(struct Student* stud, int arr[], size_t len){
    // allocate int array-
    stud->grades = (int*) calloc(sizeof(int), len);
    // copy numbers from arr into student grades-
    for (size_t i = 0; i < len; i++)
    {
        stud->grades[i] = arr[i];
    }   
}

// d)
// שימו לב! השאלה המקורית הכילה חלקית חומר שלא נלמד
// השמת ערך ריק NULL אל תוך כתובת של מצביע,
// דורשת העברת מצביע אל מצביע. נקרא גם double-pointer.
// חלק שלישי איננו בחומר הנלמד בכיתה ולכן לא יחשב
void deleteStudent(struct Student* stud){
    // first: free int array
    free(stud->grades);
    // second: free struct itself
    free(stud);

    // last: put NULL value in pointer to erase address
    stud = NULL;    // WRONG! this will NOT do anything
}


int main(){
    struct Student* student;
    char* name = "James";
    student = createStudent(name);
    printf("Student name: %s\n", student->name);

    int g[] = {10, 56, 78, 90, 45};
    addGrades(student, g, sizeof(g)/sizeof(int));
    printf("Student first grade: %d\n", student->grades[0]);

    deleteStudent(student);
    printf("Student pointer value: %p\n", student);

    return 0;
}