#include <stdio.h>
#include <stdlib.h>

int swapTails(int* arr1, int* arr2, int len1, int len2, int k){
    for (size_t i = k; i < len1 && i < len2; i++)
    {
        int temp = *(arr1+i);
        *(arr1+i) = *(arr2+i);
        *(arr2+i) = temp;
    }
}

int sortTable(int rows, int cols, int table[][cols]) {
    for (size_t i = 0; i < rows; i++)
    {
        for (size_t j = 1; j < rows; j++)
        {
            if (table[j-1][0] > table[j][0])
            {
                swapTails(table[j-1], table[j], cols, cols, 0);
            }
        }
    }
    
}


void printArr(int* a, int len){
    for (size_t i = 0; i < len; i++)
    {
        printf("%d ", a[i]);
    }
    printf("\n");
}
void printMatrix(int rows, int cols, int matrix[][cols]){
    for (size_t i = 0; i < rows; i++)
    {
        for (size_t j = 0; j < cols; j++)
        {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}
int main(int argc, char const *argv[])
{
    /*
        Before:
        a = [1,3,5,7,9]
        b = [2,4,6,8,10]
        After:
        a = [1,3,6,8,10]
        b = [2,4,5,7,9]
    */
    int a[] = {1,3,5,7,9};
    int b[] = {2,4,6,8,10};
    swapTails(a, b, 5, 5, 2);
    printArr(a, 5);
    printArr(b, 5);

    /*
        Before:
        c = [1,2,3,4,5,6,7,8]
        d = [10,20,30,40,50]
        After:
        c = [1,2,30,40,50,6,7,8]
        d = [10,20,3,4,5]
    */
    int c[] = {1,2,3,4,5,6,7,8};
    int d[] = {10,20,30,40,50};
    swapTails(c, d, 5, 5, 2);
    printArr(c, 8);
    printArr(d, 5);


    /*
        Before:
        [
            [3,6,3,8,9],
            [4,5,7,9,7],
            [2,1,4,5,6],
            [1,2,8,5,3]
        ]
        After:
        [
            [1,2,8,5,3],
            [2,1,4,5,6],
            [3,6,3,8,9],
            [4,5,7,9,7]
        ]
    */
   int matrix[][5] = {
            {3,6,3,8,9},
            {4,5,7,9,7},
            {2,1,4,5,6},
            {1,2,8,5,3}
   };
   sortTable(4, 5, matrix);
   printMatrix(4, 5, matrix);


    return 0;
}
